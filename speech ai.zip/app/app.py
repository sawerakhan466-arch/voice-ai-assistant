import gradio as gr
import requests
import json
import base64
from io import BytesIO
from groq import Groq

# Initialize Groq Client
client = Groq(api_key="YOUR_GROQ_API_KEY")

# Models (as per current Groq docs)
ASR_MODEL = "whisper-large-v3"
LLM_MODEL = "llama-3.1-70b-versatile"
TTS_MODEL = "bark-small"

def transcribe_audio(audio_file):
    with open(audio_file, "rb") as f:
        transcription = client.audio.transcriptions.create(model=ASR_MODEL, file=f)
    return transcription.text

def generate_response(prompt, history):
    messages = [{"role": "system", "content": "You are 100era's Baat GPT, a helpful Pakistani AI assistant."}]
    for h in history:
        messages.append({"role": "user", "content": h[0]})
        messages.append({"role": "assistant", "content": h[1]})
    messages.append({"role": "user", "content": prompt})

    stream = client.chat.completions.create(
        model=LLM_MODEL,
        messages=messages,
        stream=True,
    )

    response_text = ""
    for chunk in stream:
        if hasattr(chunk.choices[0].delta, "content"):
            token = chunk.choices[0].delta.content or ""
            response_text += token
            yield response_text

def text_to_speech(text):
    speech = client.audio.speech.create(model=TTS_MODEL, voice="en_speaker_6", input=text)
    audio_base64 = speech.audio
    audio_bytes = base64.b64decode(audio_base64)
    return BytesIO(audio_bytes)

def process_conversation(audio, history):
    user_text = transcribe_audio(audio)
    response_gen = generate_response(user_text, history)
    response_text = ""
    for partial in response_gen:
        response_text = partial
    audio_output = text_to_speech(response_text)
    history.append((user_text, response_text))
    return history, gr.Audio(value=audio_output, format="mp3")

with gr.Blocks(title="100era's Baat GPT") as demo:
    gr.Markdown("# 🧠 100era's Baat GPT – Voice Assistant (Groq-Powered)")
    chatbot = gr.Chatbot()
    audio_input = gr.Audio(source="microphone", type="filepath", label="Speak here")
    state = gr.State([])
    submit = gr.Button("🎙️ Talk to GPT")

    submit.click(process_conversation, inputs=[audio_input, state], outputs=[chatbot, chatbot])

demo.launch()
