# 🧠 100era's Baat GPT
A free AI-powered speech-to-speech assistant built entirely with Groq models.

### Features
- 🎤 Voice input (English)
- 💬 Context-aware intelligent responses
- 🔊 AI speech output (text-to-speech)
- ⚡ Streaming, context-retaining chat experience
- 🧱 100% free Groq-hosted models

### Tech Stack
- **Frontend**: Gradio
- **LLM**: `llama-3.1-70b-versatile`
- **Speech-to-Text (ASR)**: `whisper-large-v3`
- **Text-to-Speech (TTS)**: `bark-small`
- **Environment**: Google Colab + Hugging Face Spaces

### Deployment
```bash
!pip install -r requirements.txt
!streamlit run app/app.py
```
